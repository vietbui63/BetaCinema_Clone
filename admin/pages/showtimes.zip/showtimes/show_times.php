<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>SHOWTIMES</title>
</head>
<body>
    <?php
        require 'config.php';

        $query = "SELECT st.ShowtimeID, m.MoviesID AS MovieID, m.Title AS MovieTitle, st.ShowDate, st.StartTime, st.EndTime, h.HallName
                    FROM show_times st
                    JOIN movies m ON st.MovieID = m.MoviesID
                    JOIN halls h ON st.HallID = h.HallID
                    ORDER BY m.MoviesID, st.ShowDate, st.StartTime";

        $result = mysqli_query($connect, $query);
    ?>
    <div class="container mt-5">
        <a href="/BetaCinema_Clone/admin/pages/showtimes/add_showtimes.php" class="btn btn-success text-center mt-5">THÊM MỚI SHOWTIMES</a>
        <table class="table table-info table-bordered border-info table-striped mt-3" id="font">
            <thead>
                <tr class="text-center">
                    <th scope="col">Showtime ID</th>
                    <th scope="col">Movie ID</th>
                    <th scope="col">Tên phim</th>
                    <th scope="col">Ngày chiếu</th>
                    <th scope="col">Giờ chiếu</th>
                    <th scope="col">Giờ kết thúc</th>
                    <th scope="col">Phòng chiếu</th>
                    <th scope="col">Function</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Initialize variables
                    $previousMovieID = null;
                    $previousMovieTitle = null;
                    
                    // Loop through the result set and display showtimes
                    while ($row = $result->fetch_assoc()) {
                        // If we are at a new movie, display the movie title once
                        if ($row["MovieID"] != $previousMovieID) {
                            $previousMovieID = $row["MovieID"];
                            $previousMovieTitle = $row["MovieTitle"];
                        }

                        // Display the showtime details for this movie
                        echo "<tr class='text-center'>
                                <td>" . $row["ShowtimeID"] . "</td>
                                <td>" . $row["MovieID"] . "</td>
                                <td>" . $previousMovieTitle . "</td>
                                <td>" . (!empty($row['ShowDate']) ? date("d/m/Y", strtotime($row['ShowDate'])) : "N/A") . "</td>
                                <td>" . $row["StartTime"] . "</td>
                                <td>" . $row["EndTime"] . "</td>
                                <td>" . $row["HallName"] . "</td>
                                <td>
                                    <a href='/BetaCinema_Clone/admin/pages/showtimes/edit_showtimes.php?id=" . htmlspecialchars($row['ShowtimeID']) . "' class='btn btn-warning btn-sm'>SỬA</a>
                                    <a href='/BetaCinema_Clone/admin/pages/showtimes/delete_showtimes.php?id=" . htmlspecialchars($row['ShowtimeID']) . "' class='btn btn-danger btn-sm' onclick=\"return confirm('Bạn có chắc chắn muốn xoá user này không?');\">XOÁ</a>
                                </td>
                            </tr>";
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>

<style>
    thead th {
        white-space: nowrap; 
        overflow: hidden;  
        text-overflow: ellipsis; 
        max-width: 200px;
        text-transform: uppercase;
    }

    tbody td {
        white-space: nowrap; 
        overflow: hidden;  
        text-overflow: ellipsis; 
        max-width: 150px; 
    }
    #font {
        font-size: 14px;
    }
</style>
</html>
